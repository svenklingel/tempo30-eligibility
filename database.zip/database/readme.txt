# PostGIS database used to store OSM data and identify roads eligible for Tempo 30 zones

# SQL uses to analyze roads eligible for Tempo 30 zones and writes the results to a separate table.

